from gym_snake.envs.snake_env import SnakeEnv
from gym_snake.envs.snake_extrahard_env import SnakeExtraHardEnv
