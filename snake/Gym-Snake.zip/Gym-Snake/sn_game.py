import gym
import gym_snake
import numpy as np
from gym import wrappers

# Construct Environment
env = gym.make('snake-v0')
observation_n = env.reset() 
print(np.shape(observation_n))
y = np.squeeze(observation_n ,axis=2)
print(np.shape(y))
done = False
cnt = 0
best_weights = np.zeros(4)
best_length = 0

for i in range(100):
    new_weights = np.random.uniform(-1.0,1.0,150)
    length = []

    for j in range(100) :
        observation_n = env.reset() 
        done = False
        cnt = 0
        while not done:
            #env.render()
            cnt+=1
            action = 1 if np.dot(np.squeeze(observation_n) , np.squeeze(new_weights)) > 0  else 0
            observation , reward , done , _ = env.step(action)

            if done:
                break
        length.append(cnt)

    average_length = float(sum(length) / len(length))
    if average_length > best_length:
        best_length = average_length
        best_weights = new_weights


    if i % 10 == 0 :
        print('best length is ' , best_length)

done = False
cnt = 0
            
'''while not done:
	#env.render()
	cnt+=1
	action = 1 if np.dot(observation_n , new_weights) > 0  else 0
    observation , reward , done , _ = env.step(action)

	if done:
		break

print("with best weights game lasted" ,cnt , 'moves')
'''